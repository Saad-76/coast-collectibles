import NavbarLogo from '../../assets/img/core-img/logo.png'

import TopSellersauthors1 from "../../assets/img/authors/1.png"
import TopSellersauthors2 from "../../assets/img/authors/2.png"
import TopSellersauthors3 from "../../assets/img/authors/3.png"
import TopSellersauthors4 from "../../assets/img/authors/4.png"
import TopSellersauthors5 from "../../assets/img/authors/5.png"
import TopSellersauthors6 from "../../assets/img/authors/6.png"
import TopSellersauthors7 from "../../assets/img/authors/7.png"
import TopSellersauthors8 from "../../assets/img/authors/8.png"
import TopSellersauthors9 from "../../assets/img/authors/9.png"
import TopSellersauthors10 from "../../assets/img/authors/10.png"
import TopSellersauthors11 from "../../assets/img/authors/11.png"
import TopSellersauthors12 from "../../assets/img/authors/12.png"

import TopCollectionsworkc1 from "../../assets/img/art-work/c1.png"
import TopCollectionsworkc2 from "../../assets/img/art-work/c2.png"
import TopCollectionsworkc3 from "../../assets/img/art-work/c3.png"
import TopCollectionsworkc4 from "../../assets/img/art-work/c4.png"


import ListedItemsArtwork1 from "../../assets/img/art-work/1.png"
import ListedItemsArtwork2 from "../../assets/img/art-work/2.png"
import ListedItemsArtwork3 from "../../assets/img/art-work/3.png"
import ListedItemsArtwork4 from "../../assets/img/art-work/4.png"
import ListedItemsArtwork5 from "../../assets/img/art-work/5.png"
import ListedItemsArtwork6 from "../../assets/img/art-work/6.png"
import ListedItemsArtwork7 from "../../assets/img/art-work/7.png"
import ListedItemsArtwork8 from "../../assets/img/art-work/8.png"

import ListedItemsAuthors2 from "../../assets/img/authors/2.png"
import ListedItemsAuthors3 from "../../assets/img/authors/3.png"
import ListedItemsAuthors8 from "../../assets/img/authors/8.png"
import ListedItemsAuthors6 from "../../assets/img/authors/6.png"

import LiveAuctionsArtwork9 from "../../assets/img/art-work/9.png"
import LiveAuctionsAuthors2 from "../../assets/img/authors/2.png"
import LiveAuctionsArtwork1 from "../../assets/img/art-work/1.png"
import LiveAuctionsAuthors3 from "../../assets/img/authors/3.png"
import LiveAuctionsArtwork11 from "../../assets/img/art-work/11.png"
import LiveAuctionsAuthors8 from "../../assets/img/authors/8.png"
import LiveAuctionsArtwork2 from "../../assets/img/art-work/2.png"
import LiveAuctionsAuthors6 from "../../assets/img/authors/6.png"

import ItemDetailsDetailed from "../../assets/img/art-work/detailed.jpg"
import ItemDetailsArtworkfire from "../../assets/img/art-work/fire.png"
import ItemDetailsAuthors1 from "../../assets/img/authors/1.png"
import ItemDetailsAuthors2 from "../../assets/img/authors/2.png"
import ItemDetailsAuthors3 from "../../assets/img/authors/3.png"
import ItemDetailsAuthors4 from "../../assets/img/authors/4.png"
import ItemDetailsAuthors5 from "../../assets/img/authors/5.png"
import ItemDetailsAuthors8 from "../../assets/img/authors/8.png"
import ItemDetailsIconsf1 from "../../assets/img/icons/f1.png"
import ItemDetailsArtworkdetailed from "../../assets/img/art-work/detailed.jpg"

import ActivityIconsf1 from "../../assets/img/icons/f1.png"
import ActivityIconsf2 from "../../assets/img/icons/f2.png"
import ActivityIconsf3 from "../../assets/img/icons/f3.png"
import ActivityIconsf4 from "../../assets/img/icons/f4.png"
import ActivityIconsf5 from "../../assets/img/icons/f5.png"
import ActivityIconsf6 from "../../assets/img/icons/f6.png"
import ActivityIconsf7 from "../../assets/img/icons/f7.png"

import ConnectWalletIconsw1 from "../../assets/img/icons/w1.png"
import ConnectWalletIconsw2 from "../../assets/img/icons/w2.png"
import ConnectWalletIconsw3 from "../../assets/img/icons/w3.png"
import ConnectWalletIconswallet from "../../assets/img/icons/wallet.png"
import ConnectWalletCoreimgPlatform from "../../assets/img/core-img/platform.png"
import ConnectWalletCoreimgRings from "../../assets/img/core-img/rings.png"

import ConnectWalletArtworkc1 from "../../assets/img/art-work/c1.png"
import ConnectWalletAuthors2 from "../../assets/img/authors/2.png"
import ConnectWalletArtworkc2 from "../../assets/img/art-work/c2.png"
import ConnectWalletAuthors3 from "../../assets/img/authors/3.png"
import ConnectWalletArtworkc3 from "../../assets/img/art-work/c3.png"
import ConnectWalletAuthors4 from "../../assets/img/authors/4.png"
import ConnectWalletArtworkc4 from "../../assets/img/art-work/c4.png"
import ConnectWalletAuthors5 from "../../assets/img/authors/5.png"
import ConnectWalletAuthors6 from "../../assets/img/authors/6.png"
import ConnectWalletAuthors7 from "../../assets/img/authors/7.png"
import ConnectWalletAuthors8 from "../../assets/img/authors/8.png"
import ConnectWalletAuthors9 from "../../assets/img/authors/9.png"

import CreateItemIconsf1 from "../../assets/img/icons/f1.png"
import CreateItemIconsf2 from "../../assets/img/icons/f2.png"
import CreateItemIconsf3 from "../../assets/img/icons/f3.png"
import CreateItemIconsf4 from "../../assets/img/icons/f4.png"
import CreateItemIconsf5 from "../../assets/img/icons/f5.png"
import CreateItemIconsf6 from "../../assets/img/icons/f6.png"
import CreateItemIconsf7 from "../../assets/img/icons/f7.png"

import CreateItemProfileheader from "../../assets/img/art-work/profile-header.jpg"
import CreateItemAuthors2 from "../../assets/img/authors/2.png"
import CreateItemArtworkfire from "../../assets/img/art-work/fire.png"

import AuthorsArtworkc1 from "../../assets/img/art-work/c1.png"
import AuthorsArtworkc2 from "../../assets/img/art-work/c2.png"
import AuthorsArtworkc3 from "../../assets/img/art-work/c3.png"
import AuthorsArtworkc4 from "../../assets/img/art-work/c4.png"

import AuthorsAuthors2 from "../../assets/img/authors/2.png"
import AuthorsAuthors3 from "../../assets/img/authors/3.png"
import AuthorsAuthors4 from "../../assets/img/authors/4.png"
import AuthorsAuthors5 from "../../assets/img/authors/5.png"
import AuthorsAuthors6 from "../../assets/img/authors/6.png"
import AuthorsAuthors7 from "../../assets/img/authors/7.png"
import AuthorsAuthors8 from "../../assets/img/authors/8.png"
import AuthorsAuthors9 from "../../assets/img/authors/9.png"

import ProfileArtwork1 from "../../assets/img/art-work/1.png"
import ProfileArtwork2 from "../../assets/img/art-work/2.png"
import ProfileArtwork3 from "../../assets/img/art-work/3.png"
import ProfileArtwork4 from "../../assets/img/art-work/4.png"
import ProfileArtwork5 from "../../assets/img/art-work/5.png"
import ProfileArtwork6 from "../../assets/img/art-work/6.png"
import ProfileArtwork7 from "../../assets/img/art-work/7.png"
import ProfileArtwork8 from "../../assets/img/art-work/8.png"

import ProfileAuthors3 from "../../assets/img/authors/3.png"
import ProfileAuthors8 from "../../assets/img/authors/8.png"
import ProfileAuthors6 from "../../assets/img/authors/6.png"

import ProfileProfileheader from "../../assets/img/art-work/profile-header.jpg"
import ProfileAuthors2 from "../../assets/img/authors/2.png"
import ProfileArtworkfire from "../../assets/img/art-work/fire.png"



import Ren32 from "../../assets/img/test-img/ren_0032.png"
import  Ren33 from "../../assets/img/test-img/ren_033.png"
import Ren34 from "../../assets/img/test-img/ren_034.png"
import Ren36 from "../../assets/img/test-img/ren_036.png"
import Ren46 from "../../assets/img/test-img/ren_46.png"
import Ren47 from "../../assets/img/test-img/ren_47.png"
import Ren49 from "../../assets/img/test-img/ren_49.png"
import Ren55 from "../../assets/img/test-img/ren_55.png"


import Monkey1 from "../../assets/img/test-img/Monkey1.jpg"
import Monkey2 from "../../assets/img/test-img/Monkey2.jpg"
import Monkey3 from "../../assets/img/test-img/Monkey3.jpg"
import Monkey4 from "../../assets/img/test-img/Monkey4.jpg"
import Monkey5 from "../../assets/img/test-img/Monkey5.jpg"
import Monkey6 from "../../assets/img/test-img/Monkey6.jpg"

import QuestionMark from "../../assets/img/test-img/QuestionMark.jpg"

import SnlLogo from "../../assets/img/test-img/SnlLogo.png"



export {

	NavbarLogo,

	TopSellersauthors1,
	TopSellersauthors2,
	TopSellersauthors3,
	TopSellersauthors4,
	TopSellersauthors5,
	TopSellersauthors6,
	TopSellersauthors7,
	TopSellersauthors8,
	TopSellersauthors9,
	TopSellersauthors10,
	TopSellersauthors11,
	TopSellersauthors12,

	TopCollectionsworkc1,
	TopCollectionsworkc2,
	TopCollectionsworkc3,
	TopCollectionsworkc4,

	ListedItemsArtwork1,
	ListedItemsAuthors2,
	ListedItemsArtwork2,
	ListedItemsAuthors3,
	ListedItemsArtwork3,
	ListedItemsArtwork4,
	ListedItemsArtwork5,
	ListedItemsArtwork6,
	ListedItemsArtwork7,
	ListedItemsAuthors8,
	ListedItemsArtwork8,
	ListedItemsAuthors6,

	LiveAuctionsArtwork9,
	LiveAuctionsAuthors2,
	LiveAuctionsArtwork1,
	LiveAuctionsAuthors3,
	LiveAuctionsArtwork11,
	LiveAuctionsAuthors8,
	LiveAuctionsArtwork2,
	LiveAuctionsAuthors6,


	ItemDetailsDetailed,
	ItemDetailsAuthors8,
	ItemDetailsArtworkfire,
	ItemDetailsAuthors2,
	ItemDetailsAuthors3,
	ItemDetailsAuthors4,
	ItemDetailsAuthors5,
	ItemDetailsAuthors1,
	ItemDetailsIconsf1,
	ItemDetailsArtworkdetailed,


	ActivityIconsf1,
	ActivityIconsf2,
	ActivityIconsf3,
	ActivityIconsf4,
	ActivityIconsf5,
	ActivityIconsf6,
	ActivityIconsf7,

	ConnectWalletIconswallet,
	ConnectWalletIconsw1,
	ConnectWalletIconsw2,
	ConnectWalletIconsw3,
	ConnectWalletCoreimgPlatform,
	ConnectWalletCoreimgRings,

	ConnectWalletArtworkc1,
	ConnectWalletAuthors2,
	ConnectWalletArtworkc2,
	ConnectWalletAuthors3,
	ConnectWalletArtworkc3,
	ConnectWalletAuthors4,
	ConnectWalletArtworkc4,
	ConnectWalletAuthors5,
	ConnectWalletAuthors6,
	ConnectWalletAuthors7,
	ConnectWalletAuthors8,
	ConnectWalletAuthors9,


	CreateItemIconsf1,
	CreateItemIconsf2,
	CreateItemIconsf3,
	CreateItemIconsf4,
	CreateItemIconsf5,
	CreateItemIconsf6,
	CreateItemIconsf7,

	CreateItemProfileheader,
	CreateItemAuthors2,
	CreateItemArtworkfire,


	AuthorsArtworkc1,
	AuthorsArtworkc2,
	AuthorsArtworkc3,
	AuthorsArtworkc4,
	AuthorsAuthors2,
	AuthorsAuthors3,
	AuthorsAuthors4,
	AuthorsAuthors5,
	AuthorsAuthors6,
	AuthorsAuthors7,
	AuthorsAuthors8,
	AuthorsAuthors9,


	ProfileArtwork1,
	ProfileArtwork2,
	ProfileArtwork3,
	ProfileArtwork4,
	ProfileArtwork5,
	ProfileArtwork6,
	ProfileArtwork7,
	ProfileArtwork8,
	ProfileAuthors3,
	ProfileAuthors8,
	ProfileAuthors6,

	ProfileProfileheader,
	ProfileAuthors2,
	ProfileArtworkfire,



	Ren32,
	Ren33,
	Ren34,
	Ren36,
	Ren46,
	Ren47,
	Ren49,
	Ren55,

	Monkey1,
		Monkey2,
		Monkey3,
		Monkey4,
		Monkey5,
		Monkey6,

QuestionMark,
SnlLogo,
}