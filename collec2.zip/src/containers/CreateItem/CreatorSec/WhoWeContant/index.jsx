const WhoWeContant = () => {

  return (
    <>
      <div className="who-we-contant">
          <div className="dream-dots text-left">
              <span className="gradient-text ">Create New Item</span>
          </div>
          <h4>Create Item</h4>
      </div>
    </>
  );
}

export default WhoWeContant;