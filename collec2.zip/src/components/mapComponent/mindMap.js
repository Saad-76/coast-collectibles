import React from 'react';
import "./mindMap.css"
// import InfoComponent from '../InfoComponent'
// import MapItemsItem from "../mapItemsItems/mapItemsItem"


const  MindMap=()=> {
  return (
<>




</>

  );
}

export default MindMap;

