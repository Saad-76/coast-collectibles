import {

	// TopCollections component
	TopCollectionsworkc1,
	TopCollectionsworkc2,
	TopCollectionsworkc3,
	TopCollectionsworkc4,


} from '../../utils/allImgs'

export const TopCollectionsData = [
	{
		img:TopCollectionsworkc1,
		title:'Cyberpunk City Art',
		text:'Naretor-Nole',
		Delay:'300'
	},
	{
		img:TopCollectionsworkc2,
		title:'Murphy the Mutant',
		text:'Johan Doe',
		Delay:'500'
	},
	{
		img:TopCollectionsworkc3,
		title:'Beeple Special Edition',
		text:'Nole_moreta',
		Delay:'600'
	},
	{
		img:TopCollectionsworkc4,
		title:'Floyd Mayweather Jr.',
		text:'Kera_one',
		Delay:'700'
	}
]


// export {data1 , data2 , data3}