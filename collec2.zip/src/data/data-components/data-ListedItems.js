import {

	ListedItems,
	ListedItemsArtwork1,
	ListedItemsArtwork2,
	ListedItemsArtwork3,
	ListedItemsArtwork4,
	ListedItemsArtwork5,
	ListedItemsArtwork6,
	ListedItemsArtwork7,
	ListedItemsArtwork8,
	ListedItemsAuthors2,
	ListedItemsAuthors3,
	ListedItemsAuthors8,
	ListedItemsAuthors6,

	Ren32,
	Ren33,
	Ren34,
	Ren36,
	Ren46,
	Ren47,
	Ren49,
	Ren55,

	
	Monkey1,
		Monkey2,
		Monkey3,
		Monkey4,
		Monkey5,
		Monkey6,

		QuestionMark,
SnlLogo,

} from '../../utils/allImgs'

// import {} from "../../"
 
export const ListedItemsData = [
	{
		imgBig:QuestionMark,
		imgSm:ListedItemsAuthors2,
		title:'@Coast Collectibles',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:QuestionMark,
		imgSm:ListedItemsAuthors3,
		title:'@Coast Collectibles',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:QuestionMark,
		imgSm:ListedItemsAuthors8,
		title:'@Coast Collectibles',
		price:0.081,
		bid:0.081,
	},
	{
		imgBig:QuestionMark,
		imgSm:ListedItemsAuthors6,
		title:'@Coast Collectibles',
		price:0.081,
		bid:0.081,
	},

]


// {
// 	imgBig:QuestionMark,
// 	imgSm:ListedItemsAuthors2,
// 	title:'@Coast Collectibles',
// 	price:0.081,
// 	bid:0.081,
// },
// {
// 	imgBig:QuestionMark,
// 	imgSm:ListedItemsAuthors3,
// 	title:'@Coast Collectibles',
// 	price:0.081,
// 	bid:0.081,
// },
// {
// 	imgBig:QuestionMark,
// 	imgSm:ListedItemsAuthors8,
// 	title:'@Coast Collectibles',
// 	price:0.081,
// 	bid:0.081,
// },
// {
// 	imgBig:QuestionMark,
// 	imgSm:ListedItemsAuthors6,
// 	title:'@Coast Collectibles',
// 	price:0.081,
// 	bid:0.081,
// },
// export {data1 , data2 , data3}