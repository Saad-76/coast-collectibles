import {

	// TopSellers component
	TopSellersauthors1,

	TopSellersauthors2,

	TopSellersauthors3,

	TopSellersauthors4,

	TopSellersauthors5,

	TopSellersauthors6,

	TopSellersauthors7,

	TopSellersauthors8,

	TopSellersauthors9,

	TopSellersauthors10,

	TopSellersauthors11,

	TopSellersauthors12,

} from '../../utils/allImgs'


export const TopSellersData1 = [
	{
		rank:"01",
		img:TopSellersauthors1,
		title:'LarySmith-30',
		price:647.34
	},
	{
		rank:"02",
		img:TopSellersauthors2,
		title:'Amillia Nnor',
		price:521.85
	},
	{
		rank:"03",
		img:TopSellersauthors3,
		title:'Naretor-Nole',
		price:511.45
	},
	{
		rank:"04",
		img:TopSellersauthors4,
		title:'Johan Donem',
		price:499.11
	},
]

export const TopSellersData2 = [
	{
		rank:"05",
		img:TopSellersauthors5,
		title:'LarySmith-30',
		price:647.34
	},
	{
		rank:"06",
		img:TopSellersauthors6,
		title:'Amillia Nnor',
		price:521.85
	},
	{
		rank:"07",
		img:TopSellersauthors7,
		title:'Naretor-Nole',
		price:511.45
	},
	{
		rank:"08",
		img:TopSellersauthors8,
		title:'Johan Donem',
		price:499.11
	},
]

export const TopSellersData3 = [
	{
		rank:"09",
		img:TopSellersauthors9,
		title:'LarySmith-30',
		price:647.34
	},
	{
		rank:"10",
		img:TopSellersauthors10,
		title:'Amillia Nnor',
		price:521.85
	},
	{
		rank:"11",
		img:TopSellersauthors11,
		title:'Naretor-Nole',
		price:511.45
	},
	{
		rank:"12",
		img:TopSellersauthors12,
		title:'Johan Donem',
		price:499.11
	},
]
// export {data1 , data2 , data3}