import {
	ActivityIconsf1,
	ActivityIconsf2,
	ActivityIconsf3,
	ActivityIconsf4,
	ActivityIconsf5,
	ActivityIconsf6,
	ActivityIconsf7

} from '../../utils/allImgs'

export const FilterData = [
	{
		img:ActivityIconsf1,
		text:'Listings'
	},
	{
		img:ActivityIconsf2,
		text:'Likes'
	},
	{
		img:ActivityIconsf3,
		text:'Purchases'
	},
	{
		img:ActivityIconsf4,
		text:'Sales'
	},
	{
		img:ActivityIconsf5,
		text:'Transfer'
	},
	{
		img:ActivityIconsf6,
		text:'Burns'
	},
	{
		img:ActivityIconsf7,
		text:'Bids'
	}

]

// export {timelineData , FilterData}