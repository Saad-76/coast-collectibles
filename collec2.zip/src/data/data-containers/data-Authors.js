import {

	// Authors Component
	AuthorsArtworkc1,
	AuthorsArtworkc2,
	AuthorsArtworkc3,
	AuthorsArtworkc4,
	AuthorsAuthors2,
	AuthorsAuthors3,
	AuthorsAuthors4,
	AuthorsAuthors5,
	AuthorsAuthors6,
	AuthorsAuthors7,
	AuthorsAuthors8,
	AuthorsAuthors9,

} from '../../utils/allImgs'


export const AuthorsData = [
	{
		imgBig:AuthorsArtworkc1,
		imgSm:AuthorsAuthors2,
		name:'Morgan Wright'
	},
	{
		imgBig:AuthorsArtworkc2,
		imgSm:AuthorsAuthors3,
		name:'Sendos Ali'
	},
	{
		imgBig:AuthorsArtworkc3,
		imgSm:AuthorsAuthors4,
		name:'Kamilia Norsh'
	},
	{
		imgBig:AuthorsArtworkc4,
		imgSm:AuthorsAuthors5,
		name:'Semova Altena'
	},
	{
		imgBig:AuthorsArtworkc1,
		imgSm:AuthorsAuthors6,
		name:'Naretor-Nole'
	},
	{
		imgBig:AuthorsArtworkc2,
		imgSm:AuthorsAuthors7,
		name:'Johan Donem'
	},
	{
		imgBig:AuthorsArtworkc3,
		imgSm:AuthorsAuthors8,
		name:'Amillia Nnor'
	},
	{
		imgBig:AuthorsArtworkc4,
		imgSm:AuthorsAuthors9,
		name:'LarySmith-30'
	},
]


// export {data1 , data2 , data3}