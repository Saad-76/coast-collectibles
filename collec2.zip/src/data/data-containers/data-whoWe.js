import {
	ConnectWalletIconsw1,
	ConnectWalletIconsw2,
	ConnectWalletIconsw3,

} from '../../utils/allImgs'

export const whoWeData = [
	{img:ConnectWalletIconsw1,text:'connect with MetaMask'},
	{img:ConnectWalletIconsw2,text:'connect with WalletConnect'},
	{img:ConnectWalletIconsw3,text:'connect with Ledger'}
]